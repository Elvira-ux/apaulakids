
export enum Region {
  Nordic = "Nòrdica",
  Western = "Occidental",
  Central = "Central",
  Eastern = "Oriental",
  Balkans = "Balcans",
  Mediterranean = "Mediterrània"
}

export interface Country {
  name: string;
  capital: string;
  region: Region;
  code: string;
  euro: boolean;
}

export interface Question {
  question: string;
  options: string[];
  correct: number;
}

export interface TrapChallenge {
  question: string;
  options: { label: string; flag: string }[];
  correct: number;
}

export type View = 'home' | 'data' | 'puzzle' | 'trap' | 'cards' | 'exam' | 'tutor';

export interface UserStats {
  bestScore: number;
  attempts: number;
  xp: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
